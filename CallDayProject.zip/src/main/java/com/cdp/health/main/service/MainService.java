package com.cdp.health.main.service;

public interface MainService {

}
