package com.cdp.health.exercise.service;

import java.util.List;

import com.cdp.health.dto.HealthDTO;

public interface ExerciseService {

	List<HealthDTO> getExercisesByPart(String part);
	
	HealthDTO getExerciseById(int exId);
	
	

}
