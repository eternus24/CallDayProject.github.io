   
   9.16 4조 헬스 커뮤니티  프로젝트 시작 
   
   
   1. HealthDTO =====================================
   
   HealthDTO -> // xercise DTO 를 만들어서 
   내가 맡은 파트의 모든 변수들을 넣어서 저장
   
   모든 DTO 의 변수들은 하나의 DTO로 사용하기로 했음
   
   =====================================================
   
   2. ExerciseController
   
   	HTTP 요청을 받아 응답하는 컴보넌트이다.
  	스프링 부트가 자동으로  Bean을 생성한다. 
  	Spring MVC 구조에서JSP 같은 View 파일이 
  	없어도 실행은 가능하기 때문에 직관적으로
  	확인하면서 진행할 수 있어서 좋다. 
  	

영어 뜻 그대로 "조종하는 사람"
→ 사용자의 요청(Request)을 받고, 
응답(Response)을 주는 입구/출구 역할.

웹 브라우저나 Postman 같은 클라이언트가 
URL 요청을 보내면 Controller가 먼저 받음.

비즈니스 로직(계산, 데이터 처리) 은 직접 하지 않음. 
대신 Service에게 위임.

주 기능: URL 매핑 (@GetMapping, @PostMapping 등)
요청 파라미터 받아오기 (예: @RequestParam, @PathVariable)
Service 호출

View(JSP) 또는 JSON 리턴
  	
  	====================================================
  	
  	 Controller ↔ Service 연결고리

Controller는 Service를 의존하고, Service는 실제 동작을 수행함.



구조를 그림으로 표현하면:

[브라우저 요청] → [Controller] → [Service] → [DAO/Repository] → [DB]
                                   ↑
                             (실제 비즈니스 로직)
   
   1) @GetMapping("/exPart")
	public String getExerciseByPart
	
	사용자가 어떤부위(part)에 해당하는 운동 목록을 보려고 /exPart로 요청하면, 컨트롤러가 그 요청을 받아서 서비스에게 DB 조회를 요청하고, 	결과 리스트를 **모델에 담아 JSP(view)**로 보내 화면에 보여준다.
	
	@GetMapping("/exPart")
	이 메소드는 브라우저에서 GET 방식으로 /exPart 요청이 들어오면 실행
	
	model.addAttribute("exList", exList);

내가 jsp에서 부위별 운동목록을 링크로 보여줄지 , 
아니면 반복문으로 돌려서 운동정보를 출력할지 정해지지 
않아서 아직은 고민중.. 

링크로 넘긴다면 

@GetMapping("{part}")
	이 메소드는 브라우저에서 GET 방식으로 /exPart 요청이 들어오면 실행
	이게 맞는 방식이고 
	
	<c:forEach>로 반복문 돌려서 운동 정보를 출력 방식을 택한다면 
 @GetMapping("/exPart/{part}")
    public String getExerciseByPart(@PathVariable("part") String part, Model model) {
    
    "/exPart/{part} 으로 매핑을 설정하고 @PathVariable 넣어주면됨 
    <h2>운동 부위: ${exPart}</h2>

<c:forEach var="item" items="${exList}">
    <div>
        <p>운동 이름: ${item.exName}</p>
        <p>효과: ${item.effect}</p>
        <p>방법: ${item.method}</p>
        <hr>
    </div>
</c:forEach>
----------------------------------------------------------------------------
	  
   

    
    
    
    
