package com.cdp.health.exercise.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


import com.cdp.health.dto.HealthDTO;
import com.cdp.health.exercise.service.ExerciseService;



@Controller
public class ExerciseController {
	
	public final ExerciseService exerciseService;
	
	public ExerciseController(ExerciseService exerciseService) {
		this.exerciseService = exerciseService;
	}
	
	@GetMapping("/exPart")
	public String getExerciseByPart(
					String part,Model model){
		
		List<HealthDTO> exList = exerciseService.getExercisesByPart(part);
		
			model.addAttribute("part",part);
			model.addAttribute("exList",exList);
			
			return "health/exList";
		
		
		}
	}
	

	

