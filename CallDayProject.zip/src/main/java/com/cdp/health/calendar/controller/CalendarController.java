package com.cdp.health.calendar.controller;

import org.springframework.stereotype.Controller;

@Controller
public class CalendarController {

}
