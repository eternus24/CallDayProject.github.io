package com.cdp.health.board.service;

public class BoardServiceImpl {

}
