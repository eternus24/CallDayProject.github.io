package com.cdp.health.board.service;

public interface BoardService {
	
}
