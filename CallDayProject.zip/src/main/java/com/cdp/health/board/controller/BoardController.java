package com.cdp.health.board.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BoardController {

}
