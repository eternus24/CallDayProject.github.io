package com.cdp.health.dto;

import java.time.LocalDateTime;

import javax.persistence.Entity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class HealthDTO {
	
	 
	
	
	
	
	// Exercise DTO
	
	
    private String exSubject;    		// 운동 제목
    private String exContent;    		// 운동 설명/내용
    
    private LocalDateTime startTime; 	// 시작 시간
    private LocalDateTime endTime;   	// 끝나는 시간

    private int exId;            
    private String exPart;        // 운동 부위 
    private String exName;        // 운동 이름
    private String effect;        // 운동 효과
    private String method;        // 운동 방법
	
}
